/* Asynchronous means that you can execute multiple things at a 
time and you don't have to finish executing the current thing in order to 
move on to next one*/
console.log('Venkatesh');
setTimeout(() => {
	console.log('Mogili');
}, 1000);
console.log('JS Course');
